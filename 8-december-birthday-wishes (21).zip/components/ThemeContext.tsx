
import React, { createContext, useContext, useEffect, useState } from 'react';

export type ThemeName = 'Love' | 'Galaxy' | 'Silver' | 'Ocean' | 'Forest';
export type Mode = 'Day' | 'Night';

interface ThemeColors {
  bgMain: string;
  bgCard: string;
  bgInput: string;
  textMain: string;
  textMuted: string;
  accentPrimary: string;
  accentSecondary: string;
  borderColor: string;
  loginPattern?: string; // Identifier for special login page layout
}

interface ThemeConfig {
  name: ThemeName;
  day: ThemeColors;
  night: ThemeColors;
}

const THEMES: Record<ThemeName, ThemeConfig> = {
  Love: {
    name: 'Love',
    night: {
      bgMain: '#380d1e', // Magical Deep Rose (Soft Night)
      bgCard: 'rgba(80, 20, 40, 0.65)',
      bgInput: 'rgba(60, 10, 30, 0.6)',
      textMain: '#ffe4e6',
      textMuted: '#fbcfe8',
      accentPrimary: '#f472b6', // Pink 400
      accentSecondary: '#fbbf24', // Amber 400 (Gold)
      borderColor: 'rgba(251, 191, 36, 0.3)', // Gold Border
      loginPattern: 'heart-scatter'
    },
    day: {
      bgMain: '#fff0f5', // Lavender Blush (Light Pink)
      bgCard: 'rgba(255, 255, 255, 0.85)',
      bgInput: 'rgba(255, 240, 245, 0.8)',
      textMain: '#9d174d', // Pink 800
      textMuted: '#bc2c67',
      accentPrimary: '#ec4899', // Pink 500
      accentSecondary: '#f472b6', // Pink 400
      borderColor: 'rgba(236, 72, 153, 0.3)',
      loginPattern: 'heart-scatter'
    }
  },
  Galaxy: {
    name: 'Galaxy',
    night: {
      bgMain: '#020617', // Slate 950
      bgCard: 'rgba(15, 23, 42, 0.75)',
      bgInput: 'rgba(30, 41, 59, 0.7)',
      textMain: '#e2e8f0',
      textMuted: '#94a3b8',
      accentPrimary: '#6366f1', // Indigo 500
      accentSecondary: '#a855f7', // Purple 500
      borderColor: 'rgba(99, 102, 241, 0.3)',
      loginPattern: 'nebula-glow'
    },
    day: {
      bgMain: '#e0e7ff', // Indigo 50
      bgCard: 'rgba(255, 255, 255, 0.9)',
      bgInput: 'rgba(224, 231, 255, 0.6)',
      textMain: '#1e1b4b',
      textMuted: '#4338ca',
      accentPrimary: '#4f46e5',
      accentSecondary: '#7c3aed',
      borderColor: 'rgba(79, 70, 229, 0.2)',
      loginPattern: 'nebula-glow'
    }
  },
  Silver: {
    name: 'Silver',
    night: {
      bgMain: '#111827', // Gray 900
      bgCard: 'rgba(55, 65, 81, 0.6)',
      bgInput: 'rgba(31, 41, 55, 0.6)',
      textMain: '#f9fafb',
      textMuted: '#9ca3af',
      accentPrimary: '#e5e7eb', // Gray 200
      accentSecondary: '#9ca3af', // Gray 400
      borderColor: 'rgba(229, 231, 235, 0.3)',
      loginPattern: 'silver-elegant'
    },
    day: {
      bgMain: '#f3f4f6', // Gray 100
      bgCard: 'rgba(255, 255, 255, 0.9)',
      bgInput: 'rgba(243, 244, 246, 0.8)',
      textMain: '#111827',
      textMuted: '#4b5563',
      accentPrimary: '#6b7280',
      accentSecondary: '#374151',
      borderColor: 'rgba(107, 114, 128, 0.2)',
      loginPattern: 'silver-elegant'
    }
  },
  Ocean: {
    name: 'Ocean',
    night: {
      bgMain: '#0f172a',
      bgCard: 'rgba(30, 41, 59, 0.7)',
      bgInput: 'rgba(15, 23, 42, 0.6)',
      textMain: '#f0f9ff',
      textMuted: '#94a3b8',
      accentPrimary: '#0ea5e9',
      accentSecondary: '#2dd4bf',
      borderColor: 'rgba(14, 165, 233, 0.3)',
      loginPattern: 'classic-glass'
    },
    day: {
      bgMain: '#ecfeff',
      bgCard: 'rgba(255, 255, 255, 0.8)',
      bgInput: 'rgba(207, 250, 254, 0.5)',
      textMain: '#164e63',
      textMuted: '#155e75',
      accentPrimary: '#0891b2',
      accentSecondary: '#059669',
      borderColor: 'rgba(8, 145, 178, 0.2)',
      loginPattern: 'classic-glass'
    }
  },
  Forest: {
    name: 'Forest',
    night: {
      bgMain: '#052e16',
      bgCard: 'rgba(20, 83, 45, 0.6)',
      bgInput: 'rgba(2, 44, 34, 0.6)',
      textMain: '#f0fdf4',
      textMuted: '#86efac',
      accentPrimary: '#4ade80',
      accentSecondary: '#facc15',
      borderColor: 'rgba(74, 222, 128, 0.3)',
      loginPattern: 'classic-glass'
    },
    day: {
      bgMain: '#f0fdf4',
      bgCard: 'rgba(255, 255, 255, 0.8)',
      bgInput: 'rgba(220, 252, 231, 0.6)',
      textMain: '#14532d',
      textMuted: '#166534',
      accentPrimary: '#16a34a',
      accentSecondary: '#d97706',
      borderColor: 'rgba(22, 163, 74, 0.2)',
      loginPattern: 'classic-glass'
    }
  }
};

interface ThemeContextType {
  theme: ThemeName;
  setTheme: (t: ThemeName) => void;
  mode: Mode;
  toggleMode: () => void;
  colors: ThemeColors;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<ThemeName>('Love'); 
  const [mode, setMode] = useState<Mode>('Night'); // Default set to Night Mode as requested

  const colors = THEMES[theme][mode === 'Day' ? 'day' : 'night'];

  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--bg-main', colors.bgMain);
    root.style.setProperty('--bg-card', colors.bgCard);
    root.style.setProperty('--bg-input', colors.bgInput);
    root.style.setProperty('--text-main', colors.textMain);
    root.style.setProperty('--text-muted', colors.textMuted);
    root.style.setProperty('--accent-primary', colors.accentPrimary);
    root.style.setProperty('--accent-secondary', colors.accentSecondary);
    root.style.setProperty('--border-color', colors.borderColor);
  }, [theme, mode, colors]);

  const toggleMode = () => setMode(prev => prev === 'Day' ? 'Night' : 'Day');

  return (
    <ThemeContext.Provider value={{ theme, setTheme, mode, toggleMode, colors }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) throw new Error("useTheme must be used within a ThemeProvider");
  return context;
};
