
import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Gift, Sparkles, Snowflake, CloudFog, Flame, Moon, Flower } from 'lucide-react';

interface ScratchCardProps {
  imageSrc: string;
  text: string | React.ReactNode;
  coverText?: string;
  scratchType?: 'gold' | 'frost' | 'mist' | 'night' | 'ember' | 'rose' | 'forest';
  onReveal?: () => void;
  className?: string;
}

// --- ATMOSPHERIC EFFECTS COMPONENT ---
const CardAtmosphere: React.FC<{ type: string }> = ({ type }) => {
    // Generate particles based on type
    const particles = Array.from({ length: 15 }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 5,
        duration: Math.random() * 3 + 2,
        size: Math.random() * 10 + 5
    }));

    return (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
             {/* Dynamic Styles for Animations */}
             <style>{`
                @keyframes snowfall {
                    0% { transform: translateY(-10px) translateX(0); opacity: 0; }
                    20% { opacity: 1; }
                    100% { transform: translateY(300px) translateX(20px); opacity: 0; }
                }
                @keyframes emberRise {
                    0% { transform: translateY(300px) scale(0.5); opacity: 0; }
                    20% { opacity: 0.8; }
                    100% { transform: translateY(-50px) scale(1.5); opacity: 0; }
                }
                @keyframes mistFlow {
                    0% { transform: translateX(-20%); opacity: 0; }
                    50% { opacity: 0.4; }
                    100% { transform: translateX(20%); opacity: 0; }
                }
                @keyframes twinkle {
                    0%, 100% { opacity: 0.3; transform: scale(0.8); }
                    50% { opacity: 1; transform: scale(1.2); }
                }
                @keyframes petalFall {
                    0% { transform: translateY(-10px) rotate(0deg); opacity: 0; }
                    20% { opacity: 1; }
                    100% { transform: translateY(300px) rotate(360deg); opacity: 0; }
                }
             `}</style>

             {/* SNOW EFFECT */}
             {type === 'frost' && particles.map(p => (
                 <div key={p.id} className="absolute bg-white rounded-full opacity-0"
                      style={{
                          left: `${p.left}%`,
                          top: -20,
                          width: p.size / 2,
                          height: p.size / 2,
                          animation: `snowfall ${p.duration}s linear infinite`,
                          animationDelay: `${p.delay}s`,
                          boxShadow: '0 0 5px white'
                      }}
                 />
             ))}

             {/* EMBER EFFECT */}
             {(type === 'ember' || type === 'gold') && particles.map(p => (
                 <div key={p.id} className="absolute bg-orange-500 rounded-full opacity-0 blur-sm"
                      style={{
                          left: `${p.left}%`,
                          bottom: -20,
                          width: p.size / 2,
                          height: p.size / 2,
                          animation: `emberRise ${p.duration}s linear infinite`,
                          animationDelay: `${p.delay}s`,
                          background: 'radial-gradient(circle, #fcd34d 0%, #ef4444 100%)'
                      }}
                 />
             ))}

             {/* MIST EFFECT */}
             {type === 'mist' && (
                 <>
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-gray-200/10 to-transparent" style={{ animation: 'mistFlow 10s ease-in-out infinite alternate' }}></div>
                    <div className="absolute bottom-0 inset-x-0 h-1/2 bg-gradient-to-t from-white/10 to-transparent"></div>
                 </>
             )}

             {/* NIGHT/STARS EFFECT */}
             {(type === 'night' || type === 'forest') && particles.map(p => (
                 <div key={p.id} className="absolute text-white/60 opacity-0"
                      style={{
                          left: `${p.left}%`,
                          top: `${Math.random() * 100}%`,
                          animation: `twinkle ${p.duration}s ease-in-out infinite`,
                          animationDelay: `${p.delay}s`
                      }}
                 >
                     <Sparkles size={p.size} />
                 </div>
             ))}

             {/* ROSE PETAL EFFECT */}
             {(type === 'rose') && particles.map(p => (
                 <div key={p.id} className="absolute text-pink-500/60 opacity-0"
                      style={{
                          left: `${p.left}%`,
                          top: -20,
                          animation: `petalFall ${p.duration}s linear infinite`,
                          animationDelay: `${p.delay}s`
                      }}
                 >
                     <Flower size={p.size} fill="currentColor" />
                 </div>
             ))}
        </div>
    );
};


export const ScratchCard: React.FC<ScratchCardProps> = ({ 
  imageSrc, 
  text, 
  coverText = "Scratch Me!", 
  scratchType = 'gold',
  onReveal,
  className
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isRevealed, setIsRevealed] = useState(false);
  const [isScratching, setIsScratching] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Setup canvas
    const width = container.offsetWidth;
    const height = container.offsetHeight;
    canvas.width = width;
    canvas.height = height;

    // Gradient Configuration based on Type
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    
    switch (scratchType) {
        case 'frost':
            gradient.addColorStop(0, '#bae6fd'); 
            gradient.addColorStop(0.5, '#f0f9ff'); 
            gradient.addColorStop(1, '#7dd3fc'); 
            break;
        case 'mist':
            gradient.addColorStop(0, '#9ca3af'); 
            gradient.addColorStop(0.5, '#d1d5db'); 
            gradient.addColorStop(1, '#6b7280'); 
            break;
        case 'night':
            gradient.addColorStop(0, '#1e1b4b'); 
            gradient.addColorStop(0.5, '#312e81'); 
            gradient.addColorStop(1, '#0f172a'); 
            break;
        case 'ember':
            gradient.addColorStop(0, '#7c2d12'); 
            gradient.addColorStop(0.5, '#c2410c'); 
            gradient.addColorStop(1, '#450a0a'); 
            break;
        case 'rose':
            gradient.addColorStop(0, '#fbcfe8'); 
            gradient.addColorStop(0.5, '#f472b6'); 
            gradient.addColorStop(1, '#be185d'); 
            break;
        case 'forest':
            gradient.addColorStop(0, '#064e3b'); 
            gradient.addColorStop(0.5, '#10b981'); 
            gradient.addColorStop(1, '#022c22'); 
            break;
        case 'gold':
        default:
            gradient.addColorStop(0, '#fbbf24'); 
            gradient.addColorStop(0.5, '#fef3c7'); 
            gradient.addColorStop(1, '#d97706'); 
            break;
    }
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    // Add texture/noise
    const particleCount = 150;
    for(let i=0; i<particleCount; i++) {
        ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.3})`;
        ctx.beginPath();
        const r = Math.random() * 2;
        ctx.arc(Math.random() * width, Math.random() * height, r, 0, Math.PI * 2);
        ctx.fill();
    }

    // Add Cover Text (Title)
    const fontSize = coverText.length > 20 ? 18 : 22;
    ctx.font = `bold ${fontSize}px 'Inter', sans-serif`;
    
    if (scratchType === 'night' || scratchType === 'ember' || scratchType === 'forest') {
        ctx.fillStyle = "rgba(255,255,255,0.9)";
    } else {
        ctx.fillStyle = "rgba(15,23,42,0.8)";
    }
    
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    
    // Split long text
    const words = coverText.split(' ');
    let line = '';
    let lines = [];
    for(let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = ctx.measureText(testLine);
      const testWidth = metrics.width;
      if (testWidth > width - 40 && n > 0) {
        lines.push(line);
        line = words[n] + ' ';
      } else {
        line = testLine;
      }
    }
    lines.push(line);

    lines.forEach((l, i) => {
        const offset = (i - (lines.length-1)/2) * (fontSize + 8);
        ctx.fillText(l, width/2, height/2 + offset);
    });

    // Scratch logic
    ctx.globalCompositeOperation = 'destination-out';

    const getMousePos = (evt: MouseEvent | TouchEvent) => {
        const rect = canvas.getBoundingClientRect();
        let clientX, clientY;
        
        if ('touches' in evt) {
            clientX = evt.touches[0].clientX;
            clientY = evt.touches[0].clientY;
        } else {
            clientX = (evt as MouseEvent).clientX;
            clientY = (evt as MouseEvent).clientY;
        }

        return {
            x: clientX - rect.left,
            y: clientY - rect.top
        };
    };

    const scratch = (x: number, y: number) => {
        ctx.beginPath();
        ctx.arc(x, y, 30, 0, Math.PI * 2);
        ctx.fill();
        
        if (!isRevealed) {
            const imageData = ctx.getImageData(0, 0, width, height);
            const pixels = imageData.data;
            let transparent = 0;
            // Check sample pixels for performance
            for(let i=0; i<pixels.length; i+=100) {
                if(pixels[i+3] < 128) transparent++;
            }
            if (transparent > (pixels.length / 100) * 0.4) {
                setIsRevealed(true);
                if (onReveal) onReveal();
            }
        }
    };

    const handleStart = (e: any) => {
        setIsScratching(true);
    };

    const handleMove = (e: any) => {
        if (!isScratching) return;
        // e.preventDefault(); 
        const { x, y } = getMousePos(e);
        scratch(x, y);
    };

    const handleEnd = () => {
        setIsScratching(false);
    };

    canvas.addEventListener('mousedown', handleStart);
    canvas.addEventListener('touchstart', handleStart);
    window.addEventListener('mousemove', handleMove);
    window.addEventListener('touchmove', handleMove);
    window.addEventListener('mouseup', handleEnd);
    window.addEventListener('touchend', handleEnd);

    return () => {
        canvas.removeEventListener('mousedown', handleStart);
        canvas.removeEventListener('touchstart', handleStart);
        window.removeEventListener('mousemove', handleMove);
        window.removeEventListener('touchmove', handleMove);
        window.removeEventListener('mouseup', handleEnd);
        window.removeEventListener('touchend', handleEnd);
    };
  }, [isRevealed, isScratching, onReveal, coverText, scratchType]);

  return (
    <div ref={containerRef} className={`relative w-full h-80 rounded-2xl overflow-hidden shadow-2xl transform hover:scale-[1.02] transition-transform duration-500 ${className || ''}`}>
      {/* Background Surprise (Content Layer) */}
      <div className="absolute inset-0 bg-gray-900 flex flex-col items-center justify-center p-6 text-center isolate">
         {/* Atmospheric Effects Behind Content */}
         <CardAtmosphere type={scratchType} />
         
         <div className="relative z-10">
             {imageSrc && (
                 <motion.img 
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={isRevealed ? { scale: 1, opacity: 1 } : {}}
                    src={imageSrc} 
                    alt="Surprise" 
                    className="w-20 h-20 rounded-full mx-auto mb-4 object-cover border-2 border-white/30 shadow-[0_0_20px_rgba(255,255,255,0.2)]" 
                 />
             )}
             <div className="text-white/90 font-serif italic text-base leading-relaxed whitespace-pre-wrap drop-shadow-md">
                {text}
             </div>
         </div>
      </div>
      
      {/* Canvas Overlay (Scratch Layer) */}
      <canvas 
        ref={canvasRef}
        className={`absolute inset-0 z-20 cursor-pointer transition-opacity duration-1000 ${isRevealed ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
      />
      
      {/* Animated Icon Hint */}
      {!isRevealed && (
          <motion.div 
            animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.1, 1] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className={`absolute top-3 right-3 z-30 opacity-80 ${scratchType === 'night' ? 'text-yellow-200' : 'text-white'}`}
          >
              {scratchType === 'frost' && <Snowflake size={24}/>}
              {scratchType === 'ember' && <Flame size={24}/>}
              {scratchType === 'mist' && <CloudFog size={24}/>}
              {scratchType === 'night' && <Moon size={24}/>}
              {scratchType === 'rose' && <Flower size={24}/>}
              {scratchType === 'gold' && <Gift size={24}/>}
          </motion.div>
      )}
    </div>
  );
};
