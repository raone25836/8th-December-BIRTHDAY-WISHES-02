
import React, { useState, useEffect, useRef } from 'react';
import { Edit2, Save, X, Image as ImageIcon, Upload } from 'lucide-react';
import { db } from '../services/database';

// --- EDITABLE TEXT ---

interface EditableTextProps {
  id: string; // Unique ID for DB storage
  defaultText: string;
  isAdmin?: boolean;
  className?: string;
  multiline?: boolean;
}

export const EditableText: React.FC<EditableTextProps> = ({ id, defaultText, isAdmin, className, multiline }) => {
  const [text, setText] = useState(defaultText);
  const [isEditing, setIsEditing] = useState(false);
  const [tempText, setTempText] = useState(text);

  useEffect(() => {
    // Load saved text from DB on mount
    const saved = db.getConfig(id, defaultText);
    setText(saved);
  }, [id, defaultText]);

  const handleSave = () => {
    db.setConfig(id, tempText);
    setText(tempText);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setTempText(text);
    setIsEditing(false);
  };

  if (!isAdmin) {
    return <span className={className}>{text}</span>;
  }

  if (isEditing) {
    return (
      <div className="relative inline-block min-w-[200px] z-50 animate-pulse-glow">
        {multiline ? (
          <textarea
            value={tempText}
            onChange={(e) => setTempText(e.target.value)}
            className="w-full bg-[rgba(10,10,30,0.9)] text-cyan-300 border-2 border-cyan-500/80 rounded-lg p-3 outline-none shadow-[0_0_15px_rgba(6,182,212,0.5)] font-mono text-sm tracking-wide"
            rows={3}
            autoFocus
          />
        ) : (
          <input
            type="text"
            value={tempText}
            onChange={(e) => setTempText(e.target.value)}
            className="w-full bg-[rgba(10,10,30,0.9)] text-cyan-300 border-2 border-cyan-500/80 rounded-lg px-3 py-1 outline-none shadow-[0_0_15px_rgba(6,182,212,0.5)] font-mono text-sm tracking-wide"
            autoFocus
          />
        )}
        <div className="absolute -bottom-10 right-0 flex gap-2 z-50">
           <button onClick={handleSave} className="p-2 bg-green-600/90 rounded-full text-white hover:bg-green-500 shadow-lg border border-green-400"><Save size={16}/></button>
           <button onClick={handleCancel} className="p-2 bg-red-600/90 rounded-full text-white hover:bg-red-500 shadow-lg border border-red-400"><X size={16}/></button>
        </div>
      </div>
    );
  }

  return (
    <div 
      onClick={() => setIsEditing(true)} 
      className={`relative group cursor-pointer hover:bg-cyan-500/10 rounded px-1 transition-all ${className}`}
      title="Admin: Click to Edit"
    >
       {text}
       <span className="absolute -top-3 -right-3 opacity-0 group-hover:opacity-100 bg-cyan-600 text-white p-1.5 rounded-full shadow-lg border border-cyan-300 transition-opacity z-10">
         <Edit2 size={12} />
       </span>
    </div>
  );
};

// --- EDITABLE IMAGE ---

interface EditableImageProps {
  id: string;
  defaultSrc: string;
  isAdmin?: boolean;
  className?: string;
  alt?: string;
  onImageChange?: (newSrc: string) => void;
}

export const EditableImage: React.FC<EditableImageProps> = ({ id, defaultSrc, isAdmin, className, alt, onImageChange }) => {
  const [src, setSrc] = useState(defaultSrc);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const saved = db.getConfig(id, defaultSrc);
    setSrc(saved);
  }, [id, defaultSrc]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          const newSrc = reader.result;
          db.setConfig(id, newSrc);
          setSrc(newSrc);
          if (onImageChange) onImageChange(newSrc);
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleClick = () => {
    if (isAdmin) {
      fileInputRef.current?.click();
    }
  };

  return (
    <div className={`relative group ${isAdmin ? 'cursor-pointer' : ''} ${className}`} onClick={handleClick}>
      <img src={src} alt={alt || "Editable Content"} className="w-full h-full object-cover" />
      
      {isAdmin && (
        <>
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept="image/*" 
            onChange={handleFileChange} 
          />
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm border-2 border-dashed border-cyan-400 rounded-[inherit]">
            <div className="flex flex-col items-center text-cyan-300 font-bold tracking-widest uppercase text-xs">
              <Upload size={24} className="mb-2 animate-bounce" />
              <span>Change Image</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
