import React, { useEffect, useState } from 'react';
import { Heart, Flower, Star, Sparkles, Flower2 } from 'lucide-react';
import { useTheme } from './ThemeContext';

export const FloatingElements: React.FC = () => {
  const { colors, theme } = useTheme();
  const [elements, setElements] = useState<{ id: number, left: number, delay: number, type: 'heart' | 'flower' | 'rose' | 'star' | 'sparkle', size: number }[]>([]);

  useEffect(() => {
    // Determine which shapes to spawn based on theme
    const count = 24;
    const newElements = [];
    
    for (let i = 0; i < count; i++) {
      let type: 'heart' | 'flower' | 'rose' | 'star' | 'sparkle' = 'heart';
      const rand = Math.random();

      if (theme === 'Love') {
        // Mostly hearts and flowers/roses for Love theme
        if (rand < 0.4) type = 'heart';
        else if (rand < 0.7) type = 'rose'; // Flower2 acts as Rose
        else if (rand < 0.9) type = 'flower';
        else type = 'sparkle';
      } else if (theme === 'Galaxy') {
        type = rand > 0.4 ? 'star' : 'sparkle';
      } else if (theme === 'Silver') {
        type = rand > 0.5 ? 'sparkle' : 'star';
      } else if (theme === 'Forest') {
        type = rand > 0.4 ? 'flower' : 'sparkle';
      } else if (theme === 'Ocean') {
        type = rand > 0.7 ? 'sparkle' : 'flower'; // Bubbles represented by circles in future, but sparkles work for now
      } else {
        // Mix
        if (rand > 0.6) type = 'flower';
        if (rand > 0.8) type = 'star';
      }

      newElements.push({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 20,
        type,
        size: Math.random() * 25 + 10
      });
    }
    setElements(newElements);
  }, [theme]);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {elements.map((el) => (
        <div
          key={el.id}
          className="absolute bottom-[-50px] opacity-0"
          style={{
            left: `${el.left}%`,
            animation: `floatUp ${el.type === 'heart' ? '12s' : '18s'} linear infinite`,
            animationDelay: `${el.delay}s`,
            color: el.type === 'heart' || el.type === 'rose' ? colors.accentPrimary : colors.accentSecondary
          }}
        >
          {el.type === 'heart' && <Heart size={el.size} fill="currentColor" className="opacity-70 drop-shadow-lg" />}
          {el.type === 'flower' && <Flower size={el.size} className="opacity-60" />}
          {el.type === 'rose' && <Flower2 size={el.size} className="opacity-70 text-red-400" />}
          {el.type === 'star' && <Star size={el.size} fill="currentColor" className="opacity-60" />}
          {el.type === 'sparkle' && <Sparkles size={el.size} className="opacity-80 text-yellow-200" />}
        </div>
      ))}
    </div>
  );
};