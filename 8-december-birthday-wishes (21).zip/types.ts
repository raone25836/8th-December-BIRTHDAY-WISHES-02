

export enum UserRole {
  ADMIN = 'ADMIN',
  PRIVATE = 'PRIVATE',
  PUBLIC = 'PUBLIC',
  GUEST = 'GUEST'
}

export enum WishCategory {
  FAMILY = 'Family',
  FRIEND = 'Friend',
  OTHER = 'Other'
}

export interface Wish {
  id: string;
  senderName: string;
  message: string;
  category: WishCategory;
  timestamp: number;
  isApproved: boolean;
  style?: string;
}

export interface PrivateWish {
  id: string;
  wish: string;
  timestamp: number;
}

export interface Photo {
  id: string;
  url: string;
  caption?: string;
  timestamp: number;
  album?: 'CAROUSEL' | 'HELIX' | 'WALL'; // Added album support
}

export interface Story {
  id: string;
  author: string;
  content: string;
  type: 'MEMORY' | 'GUEST_MESSAGE'; // MEMORY = Past (Admin), GUEST = Live
  timestamp: number;
  isReplied?: boolean;
  replyContent?: string;
  photoUrl?: string; // Added photo support
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
}

export interface GreetingCard {
  id: string;
  imageUrl: string;
  message: string;
  title: string;
}

export interface SurpriseItem {
  id: string;
  title: string;
  description: string;
  isLocked: boolean;
  unlockDate?: string;
}

// Initial Mock Data
export const MOCK_WISHES: Wish[] = [
  {
    id: '1',
    senderName: 'Mom & Dad',
    message: 'Happy Birthday our princess! May your day be as sweet as you are. We are so proud of the woman you have become.',
    category: WishCategory.FAMILY,
    timestamp: Date.now() - 100000,
    isApproved: true,
    style: 'emotional'
  },
  {
    id: '2',
    senderName: 'Bestie Priya',
    message: 'Another year older, but not wiser! Just kidding, love you so much! Let\'s party hard tonight! 🎉',
    category: WishCategory.FRIEND,
    timestamp: Date.now() - 50000,
    isApproved: true,
    style: 'funny'
  }
];

export const MOCK_STORIES: Story[] = [
  {
    id: '1',
    author: 'Childhood Memory',
    content: 'Remember when you tried to bake a cake at age 5 and used salt instead of sugar? We still laugh about it!',
    type: 'MEMORY',
    timestamp: Date.now()
  },
  {
    id: '2',
    author: 'Rahul (Guest)',
    content: 'The way you helped me during exams was unforgettable. You have a heart of gold.',
    type: 'GUEST_MESSAGE',
    timestamp: Date.now()
  }
];

export const MOCK_QUIZZES: QuizQuestion[] = [
  {
    id: '1',
    question: "What is Shivani's absolute favorite comfort food?",
    options: ["Pizza", "Maggi", "Biryani", "Chocolate"],
    correctAnswer: "Maggi"
  },
  {
    id: '2',
    question: "If Shivani could travel anywhere right now, where would she go?",
    options: ["Paris", "Maldives", "New York", "Manali"],
    correctAnswer: "Paris"
  },
  {
    id: '3',
    question: "What color defines her mood today?",
    options: ["Red", "Pink", "Black", "Blue"],
    correctAnswer: "Pink"
  }
];

export const MOCK_SURPRISES: SurpriseItem[] = [
  { id: '1', title: 'Video Message', description: 'A compiled video of all your friends wishing you.', isLocked: false },
  { id: '2', title: 'The Hidden Album', description: 'Photos you thought were deleted forever!', isLocked: false },
  { id: '3', title: 'Virtual Gift', description: 'A special voucher code waiting for you.', isLocked: true }
];

export const MOCK_CARDS: GreetingCard[] = [
  { id: '1', title: "Elegance", imageUrl: "https://images.unsplash.com/photo-1490750967868-58cb75069faf?w=500", message: "To the woman who shines brighter than the stars. Happy Birthday!" },
  { id: '2', title: "Joy", imageUrl: "https://images.unsplash.com/photo-1530103862676-de3c9da59af7?w=500", message: "May your smile never fade and your joy never end." },
  { id: '3', title: "Dreams", imageUrl: "https://images.unsplash.com/photo-1516724562728-afc824a36e84?w=500", message: "Chase your dreams, they are waiting for you." },
  { id: '4', title: "Love", imageUrl: "https://images.unsplash.com/photo-1518568814500-bf0f8d125f46?w=500", message: "Surrounded by love, today and always." },
  { id: '5', title: "Magic", imageUrl: "https://images.unsplash.com/photo-1513201099705-a9746e1e201f?w=500", message: "Believe in the magic within you." },
  { id: '6', title: "Adventure", imageUrl: "https://images.unsplash.com/photo-1504196606672-aef5c9cefc92?w=500", message: "Here's to another year of adventures!" },
  { id: '7', title: "Peace", imageUrl: "https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?w=500", message: "Wishing you peace and serenity on your special day." },
  { id: '8', title: "Strength", imageUrl: "https://images.unsplash.com/photo-1499209974431-9dddcece7f88?w=500", message: "You are stronger than you know." },
  { id: '9', title: "Bloom", imageUrl: "https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=500", message: "Keep blooming, keep growing." },
  { id: '10', title: "Sparkle", imageUrl: "https://images.unsplash.com/photo-1531303435785-3853fb035c27?w=500", message: "Don't let anyone dull your sparkle." },
  { id: '11', title: "Sweetness", imageUrl: "https://images.unsplash.com/photo-1563729784474-d779b9524ee8?w=500", message: "Have the sweetest birthday ever!" },
  { id: '12', title: "Vintage", imageUrl: "https://images.unsplash.com/photo-1527481138388-31827a7c94d5?w=500", message: "Like fine wine, you get better with age." },
  { id: '13', title: "Cosmic", imageUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=500", message: "You are my universe." },
  { id: '14', title: "Vibrant", imageUrl: "https://images.unsplash.com/photo-1459749411177-d4a37196040e?w=500", message: "Stay vibrant and full of life." },
  { id: '15', title: "Classic", imageUrl: "https://images.unsplash.com/photo-1512909006721-3d6018887383?w=500", message: "Classy, fabulous, and a bit magical." }
];