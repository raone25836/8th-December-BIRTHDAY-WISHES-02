
import { Wish, PrivateWish, Photo, Story, QuizQuestion, GreetingCard, SurpriseItem, MOCK_WISHES, MOCK_STORIES, MOCK_QUIZZES, MOCK_CARDS, MOCK_SURPRISES } from '../types';

/**
 * DATABASE SERVICE
 * This acts as the backend logic layer. 
 * Structured like a Python Class for clean data manipulation.
 */

const KEYS = {
  WISHES: 'bday_wishes_db_v2',
  PRIVATE_WISHES: 'bday_private_wishes_db_v2',
  PHOTOS: 'bday_photos_db_v2',
  STORIES: 'bday_stories_db_v2',
  QUIZZES: 'bday_quizzes_db_v2',
  CARDS: 'bday_cards_db_v2',
  SURPRISES: 'bday_surprises_db_v2',
  CONFIG: 'bday_config_db_v2', // New key for dynamic text
  SECURITY_LOGS: 'bday_security_logs_v1',
  BLOCKED_USERS: 'bday_blocked_users_v1',
  SYSTEM_STATE: 'bday_system_state_v1', // New key for locks and resets
  KNOWN_USERS: 'bday_known_users_v1' // ADVANCED TRACKING
};

export interface SecurityLog {
  id: string;
  timestamp: number;
  type: 'LOGIN' | 'LOGIN_FAIL' | 'ADMIN_ACTION' | 'SYSTEM_ALERT' | 'CONFIG_CHANGE' | 'BLOCK_ACTION';
  user: string;
  details: string;
  ip: string; // Simulated IP
  device: string;
  status: 'SUCCESS' | 'WARNING' | 'CRITICAL' | 'INFO';
}

export interface BlockedUser {
    identifier: string; // Name or ID
    reason: string;
    timestamp: number;
}

export interface SystemState {
    guestLocked: boolean;
    privateLocked: boolean;
    systemLocked: boolean;
    hiddenSections: string[];
    sessionVersion: number; // Increment to force logout
}

// --- NEW: ADVANCED TRACKING INTERFACE ---
export interface KnownUser {
    id: string; // Unique Device Fingerprint
    name: string;
    role: string;
    deviceModel: string;
    ip: string;
    firstLogin: number;
    lastLogin: number;
    totalTimeSpentMinutes: number; // Duration tracking
    visitCount: number;
}

class DatabaseService {
  
  // --- Wish Management ---

  getWishes(): Wish[] {
    const stored = localStorage.getItem(KEYS.WISHES);
    if (!stored) {
      this.saveWishes(MOCK_WISHES);
      return MOCK_WISHES;
    }
    return JSON.parse(stored);
  }

  saveWishes(wishes: Wish[]): void {
    localStorage.setItem(KEYS.WISHES, JSON.stringify(wishes));
  }

  addWish(wish: Wish): Wish[] {
    const current = this.getWishes();
    const updated = [wish, ...current];
    localStorage.setItem(KEYS.WISHES, JSON.stringify(updated));
    return updated;
  }

  updateWish(updatedWish: Wish): Wish[] {
    const current = this.getWishes();
    const index = current.findIndex(w => w.id === updatedWish.id);
    if (index !== -1) {
      current[index] = updatedWish;
      localStorage.setItem(KEYS.WISHES, JSON.stringify(current));
    }
    return current;
  }

  deleteWish(id: string): Wish[] {
    const current = this.getWishes();
    const updated = current.filter(w => w.id !== id);
    localStorage.setItem(KEYS.WISHES, JSON.stringify(updated));
    return updated;
  }

  toggleApproval(id: string): Wish[] {
    const current = this.getWishes();
    const updated = current.map(w => w.id === id ? { ...w, isApproved: !w.isApproved } : w);
    localStorage.setItem(KEYS.WISHES, JSON.stringify(updated));
    return updated;
  }

  // --- Private Wish List (Make a Wish) ---

  getPrivateWishes(): PrivateWish[] {
    const stored = localStorage.getItem(KEYS.PRIVATE_WISHES);
    return stored ? JSON.parse(stored) : [];
  }

  addPrivateWish(wish: PrivateWish): PrivateWish[] {
    const current = this.getPrivateWishes();
    const updated = [wish, ...current];
    localStorage.setItem(KEYS.PRIVATE_WISHES, JSON.stringify(updated));
    return updated;
  }

  // --- Photo Gallery (Memory Lane) ---

  getPhotos(): Photo[] {
    const stored = localStorage.getItem(KEYS.PHOTOS);
    return stored ? JSON.parse(stored) : [];
  }

  addPhoto(photo: Photo): Photo[] {
    const current = this.getPhotos();
    const updated = [photo, ...current];
    localStorage.setItem(KEYS.PHOTOS, JSON.stringify(updated));
    return updated;
  }

  updatePhoto(updatedPhoto: Photo): Photo[] {
    const current = this.getPhotos();
    const index = current.findIndex(p => p.id === updatedPhoto.id);
    if (index !== -1) {
      current[index] = updatedPhoto;
      localStorage.setItem(KEYS.PHOTOS, JSON.stringify(current));
    }
    return current;
  }

  deletePhoto(id: string): Photo[] {
    const current = this.getPhotos();
    const updated = current.filter(p => p.id !== id);
    localStorage.setItem(KEYS.PHOTOS, JSON.stringify(updated));
    return updated;
  }

  // --- Stories & Guest Messages ---

  getStories(): Story[] {
    const stored = localStorage.getItem(KEYS.STORIES);
    if (!stored) {
      localStorage.setItem(KEYS.STORIES, JSON.stringify(MOCK_STORIES));
      return MOCK_STORIES;
    }
    return JSON.parse(stored);
  }

  addStory(story: Story): Story[] {
    const current = this.getStories();
    const updated = [story, ...current];
    localStorage.setItem(KEYS.STORIES, JSON.stringify(updated));
    return updated;
  }

  updateStoryReply(id: string, reply: string): Story[] {
    const current = this.getStories();
    const index = current.findIndex(s => s.id === id);
    if (index !== -1) {
      current[index] = { ...current[index], isReplied: true, replyContent: reply };
      localStorage.setItem(KEYS.STORIES, JSON.stringify(current));
    }
    return current;
  }

  updateStoryContent(id: string, content: string, author: string): Story[] {
    const current = this.getStories();
    const index = current.findIndex(s => s.id === id);
    if (index !== -1) {
      current[index] = { ...current[index], content, author };
      localStorage.setItem(KEYS.STORIES, JSON.stringify(current));
    }
    return current;
  }

  deleteStory(id: string): Story[] {
      const current = this.getStories();
      const updated = current.filter(s => s.id !== id);
      localStorage.setItem(KEYS.STORIES, JSON.stringify(updated));
      return updated;
  }

  // --- Quizzes ---

  getQuizzes(): QuizQuestion[] {
      const stored = localStorage.getItem(KEYS.QUIZZES);
      if(!stored) {
          localStorage.setItem(KEYS.QUIZZES, JSON.stringify(MOCK_QUIZZES));
          return MOCK_QUIZZES;
      }
      return JSON.parse(stored);
  }

  saveQuizzes(quizzes: QuizQuestion[]): void {
      localStorage.setItem(KEYS.QUIZZES, JSON.stringify(quizzes));
  }

  // --- Greeting Cards ---

  getCards(): GreetingCard[] {
      const stored = localStorage.getItem(KEYS.CARDS);
      if(!stored) {
          localStorage.setItem(KEYS.CARDS, JSON.stringify(MOCK_CARDS));
          return MOCK_CARDS;
      }
      return JSON.parse(stored);
  }

  saveCards(cards: GreetingCard[]): void {
      localStorage.setItem(KEYS.CARDS, JSON.stringify(cards));
  }

  // --- Surprises ---

  getSurprises(): SurpriseItem[] {
      const stored = localStorage.getItem(KEYS.SURPRISES);
      if(!stored) {
          localStorage.setItem(KEYS.SURPRISES, JSON.stringify(MOCK_SURPRISES));
          return MOCK_SURPRISES;
      }
      return JSON.parse(stored);
  }

  saveSurprises(items: SurpriseItem[]): void {
      localStorage.setItem(KEYS.SURPRISES, JSON.stringify(items));
  }

  // --- Dynamic Config (Text Editing) ---
  
  getConfig(key: string, defaultValue: string): string {
      const stored = localStorage.getItem(KEYS.CONFIG);
      const config = stored ? JSON.parse(stored) : {};
      return config[key] || defaultValue;
  }

  setConfig(key: string, value: string): void {
      const stored = localStorage.getItem(KEYS.CONFIG);
      const config = stored ? JSON.parse(stored) : {};
      
      // Log critical config changes
      if (key.includes('code') || key.includes('password')) {
          this.logSecurityEvent('CONFIG_CHANGE', `Admin changed config key: ${key}`, 'System', 'WARNING');
      }

      config[key] = value;
      localStorage.setItem(KEYS.CONFIG, JSON.stringify(config));
  }

  // --- SYSTEM CONTROL & LOCKS ---

  getSystemState(): SystemState {
      const stored = localStorage.getItem(KEYS.SYSTEM_STATE);
      if (!stored) {
          const defaultState: SystemState = {
              guestLocked: false,
              privateLocked: false,
              systemLocked: false,
              hiddenSections: [],
              sessionVersion: 1
          };
          localStorage.setItem(KEYS.SYSTEM_STATE, JSON.stringify(defaultState));
          return defaultState;
      }
      return JSON.parse(stored);
  }

  setSystemState(state: SystemState): void {
      localStorage.setItem(KEYS.SYSTEM_STATE, JSON.stringify(state));
  }

  toggleSystemLock(type: 'GUEST' | 'PRIVATE' | 'SYSTEM', isLocked: boolean): void {
      const state = this.getSystemState();
      if (type === 'GUEST') state.guestLocked = isLocked;
      if (type === 'PRIVATE') state.privateLocked = isLocked;
      if (type === 'SYSTEM') state.systemLocked = isLocked;
      this.setSystemState(state);
      this.logSecurityEvent('SYSTEM_ALERT', `${type} access was ${isLocked ? 'LOCKED' : 'UNLOCKED'}`, 'Admin', 'CRITICAL');
  }

  // --- RENEW / RESET FUNCTIONS ---

  renewPrivateExperience(): void {
      // 1. Relock all surprises in DB
      const surprises = this.getSurprises().map(s => ({...s, isLocked: true}));
      this.saveSurprises(surprises);
      this.logSecurityEvent('ADMIN_ACTION', 'Private Experience Renewed (Surprises Re-locked)', 'Admin', 'INFO');
  }

  resetGallery(): void {
      localStorage.removeItem(KEYS.PHOTOS);
      this.logSecurityEvent('ADMIN_ACTION', 'Photo Gallery Reset to Factory Defaults', 'Admin', 'WARNING');
  }

  forceLogoutAll(): void {
      const state = this.getSystemState();
      state.sessionVersion += 1;
      this.setSystemState(state);
      this.logSecurityEvent('SYSTEM_ALERT', 'Global Logout Initiated', 'Admin', 'CRITICAL');
  }

  // --- ADVANCED USER TRACKING SYSTEM ---

  getKnownUsers(): KnownUser[] {
      const stored = localStorage.getItem(KEYS.KNOWN_USERS);
      return stored ? JSON.parse(stored) : [];
  }

  saveKnownUsers(users: KnownUser[]): void {
      localStorage.setItem(KEYS.KNOWN_USERS, JSON.stringify(users));
  }

  // Called when a user logs in (or auto-logs in)
  trackUserLogin(deviceId: string, name: string, role: string): void {
      const users = this.getKnownUsers();
      const existingUser = users.find(u => u.id === deviceId);
      const ip = this.simulateIP();
      const deviceModel = navigator.userAgent.split(')')[0].replace('Mozilla/5.0 (', '') || 'Unknown Device';

      if (existingUser) {
          existingUser.lastLogin = Date.now();
          existingUser.visitCount += 1;
          // Update name if changed
          if (name && name !== existingUser.name) existingUser.name = name;
          // Always update role/ip
          existingUser.role = role;
          existingUser.ip = ip;
          
          this.saveKnownUsers(users);
      } else {
          const newUser: KnownUser = {
              id: deviceId,
              name: name || 'Anonymous',
              role,
              deviceModel,
              ip,
              firstLogin: Date.now(),
              lastLogin: Date.now(),
              totalTimeSpentMinutes: 0,
              visitCount: 1
          };
          this.saveKnownUsers([newUser, ...users]);
      }
  }

  // Called periodically (Heartbeat) to update time spent
  trackUserHeartbeat(deviceId: string): void {
      const users = this.getKnownUsers();
      const user = users.find(u => u.id === deviceId);
      if (user) {
          // Increment by 1 minute (assuming heartbeat is called every 60s)
          // To be more precise, we could add small fractions, but 1 min resolution is fine
          user.totalTimeSpentMinutes += 1;
          this.saveKnownUsers(users);
      }
  }

  // --- SECURITY & LOGGING SYSTEM ---

  getSecurityLogs(): SecurityLog[] {
      const stored = localStorage.getItem(KEYS.SECURITY_LOGS);
      return stored ? JSON.parse(stored) : [];
  }

  logSecurityEvent(
      type: SecurityLog['type'], 
      details: string, 
      user: string = 'Anonymous', 
      status: SecurityLog['status'] = 'INFO'
  ): void {
      const logs = this.getSecurityLogs();
      const newLog: SecurityLog = {
          id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
          timestamp: Date.now(),
          type,
          user,
          details,
          ip: this.simulateIP(), 
          device: navigator.userAgent.split(')')[0].replace('Mozilla/5.0 (', '') || 'Unknown Device',
          status
      };
      // Keep only last 100 logs
      const updated = [newLog, ...logs].slice(0, 100); 
      localStorage.setItem(KEYS.SECURITY_LOGS, JSON.stringify(updated));
  }

  simulateIP(): string {
      // Since we can't get real IP in client JS, we simulate a consistent one for the session or random
      return `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
  }

  // Blocking System
  getBlockedUsers(): BlockedUser[] {
      const stored = localStorage.getItem(KEYS.BLOCKED_USERS);
      return stored ? JSON.parse(stored) : [];
  }

  blockUser(identifier: string, reason: string): void {
      const blocked = this.getBlockedUsers();
      if (!blocked.find(u => u.identifier === identifier)) {
          blocked.push({ identifier, reason, timestamp: Date.now() });
          localStorage.setItem(KEYS.BLOCKED_USERS, JSON.stringify(blocked));
          this.logSecurityEvent('BLOCK_ACTION', `User ${identifier} was blocked. Reason: ${reason}`, 'Admin', 'CRITICAL');
      }
  }

  unblockUser(identifier: string): void {
      const blocked = this.getBlockedUsers();
      const updated = blocked.filter(u => u.identifier !== identifier);
      localStorage.setItem(KEYS.BLOCKED_USERS, JSON.stringify(updated));
      this.logSecurityEvent('BLOCK_ACTION', `User ${identifier} was unblocked.`, 'Admin', 'WARNING');
  }

  isUserBlocked(identifier: string): boolean {
      const blocked = this.getBlockedUsers();
      return blocked.some(u => u.identifier.toLowerCase() === identifier.toLowerCase());
  }

  getActiveSessions(): SecurityLog[] {
      // Filter logs for successful logins in the last 60 minutes
      const logs = this.getSecurityLogs();
      const oneHourAgo = Date.now() - 60 * 60 * 1000;
      
      const recentLogins = logs.filter(l => l.type === 'LOGIN' && l.status === 'SUCCESS' && l.timestamp > oneHourAgo);
      
      const uniqueSessions = new Map();
      recentLogins.forEach(log => {
          if (!uniqueSessions.has(log.user)) {
              uniqueSessions.set(log.user, log);
          }
      });
      
      return Array.from(uniqueSessions.values());
  }

  // --- Admin Stats ---
  getSystemStats() {
    return {
        wishes: this.getWishes().length,
        photos: this.getPhotos().length,
        stories: this.getStories().length,
        pendingWishes: this.getWishes().filter(w => !w.isApproved).length,
        activeUsers: this.getActiveSessions().length,
        securityAlerts: this.getSecurityLogs().filter(l => l.status === 'CRITICAL' || l.status === 'WARNING').length
    }
  }

  // --- System ---
  clearAllData(): void {
      localStorage.clear();
      window.location.reload();
  }
}

export const db = new DatabaseService();
