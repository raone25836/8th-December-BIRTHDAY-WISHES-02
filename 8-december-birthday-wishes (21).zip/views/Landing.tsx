
import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Star } from 'lucide-react';
import { PageTransition } from '../components/UI';
import { useTheme } from '../components/ThemeContext';

interface LandingProps {
  onStart: () => void;
}

export const LandingView: React.FC<LandingProps> = ({ onStart }) => {
  const { colors } = useTheme();

  return (
    <PageTransition>
      <div className="min-h-screen flex flex-col items-center justify-center text-center p-6 relative z-10">
        
        {/* Animated Title */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className="mb-8"
        >
          <h1 className="text-6xl md:text-8xl font-bold cursive mb-4 gold-text-shimmer leading-tight py-2">
            8th December
          </h1>
          <motion.div 
             animate={{ opacity: [0.5, 1, 0.5] }} 
             transition={{ duration: 3, repeat: Infinity }}
             className="text-xl md:text-2xl text-[var(--accent-primary)] font-light tracking-widest uppercase"
          >
            A Magical Celebration
          </motion.div>
        </motion.div>

        {/* Decorator Line */}
        <motion.div 
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="h-px w-24 md:w-48 bg-gradient-to-r from-transparent via-[var(--accent-secondary)] to-transparent mb-12"
        />

        {/* Start Button */}
        <motion.button
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1, duration: 0.5 }}
          onClick={onStart}
          className="group relative px-10 py-5 rounded-2xl bg-gradient-to-r from-[var(--accent-secondary)] to-[#fbbf24] text-[#0b1026] font-bold text-lg md:text-xl shadow-[0_0_30px_rgba(245,158,11,0.4)] hover:shadow-[0_0_50px_rgba(245,158,11,0.6)] transition-all transform hover:-translate-y-1 active:translate-y-0 overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
          <span className="relative z-10 flex items-center gap-3">
             <Sparkles className="animate-spin-slow" /> Start The Magic <Sparkles className="animate-spin-slow" />
          </span>
        </motion.button>

        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          className="mt-8 text-[var(--text-muted)] text-sm max-w-md mx-auto"
        >
           Get ready for a surprise filled with memories, wishes, and love.
        </motion.p>
      </div>
    </PageTransition>
  );
};
