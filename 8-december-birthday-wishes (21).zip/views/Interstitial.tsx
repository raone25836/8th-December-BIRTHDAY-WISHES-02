
import React from 'react';
import { motion } from 'framer-motion';
import { Gift, Heart, Stars } from 'lucide-react';
import { PageTransition, GlassCard, BottomBackButton } from '../components/UI';

interface InterstitialProps {
  type: 'GUEST' | 'PRIVATE';
  onComplete: () => void;
  userName: string;
  onBack: () => void;
}

export const InterstitialView: React.FC<InterstitialProps> = ({ type, onComplete, userName, onBack }) => {
  
  // PRIVATE USER VIEW (The "Open Surprise" style)
  if (type === 'PRIVATE') {
    return (
      <PageTransition>
        <div className="min-h-screen flex flex-col items-center justify-center text-center p-6 relative z-10 pb-20 pt-24">
          <motion.div
             initial={{ scale: 0.8, opacity: 0 }}
             animate={{ scale: 1, opacity: 1 }}
             transition={{ duration: 0.8, type: "spring" }}
          >
             <h1 className="text-6xl md:text-8xl font-bold cursive text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.5)] mb-6">
                Happy Birthday!
             </h1>
             <p className="text-xl md:text-2xl text-pink-300 mb-12 max-w-lg mx-auto leading-relaxed">
                A magical wish for someone truly special. <br/>
                Welcome back, <span className="font-bold text-white">{userName}</span>.
             </p>

             <motion.button
                onClick={onComplete}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="group relative px-12 py-4 rounded-2xl bg-gradient-to-r from-[#f59e0b] via-[#fbbf24] to-[#f59e0b] text-gray-900 font-bold text-xl shadow-[0_0_40px_rgba(245,158,11,0.5)]"
             >
                <span className="relative z-10 flex items-center gap-3">
                   <Gift className="group-hover:rotate-12 transition-transform" /> Open Surprise
                </span>
                <div className="absolute inset-0 rounded-2xl ring-2 ring-white/50 animate-pulse"></div>
             </motion.button>
          </motion.div>
        </div>
        <BottomBackButton onClick={onBack} />
      </PageTransition>
    );
  }

  // GUEST USER VIEW (Unique Message)
  return (
    <PageTransition>
      <div className="min-h-screen flex items-center justify-center p-4 relative z-10 pb-20 pt-24">
         <GlassCard className="max-w-2xl w-full p-8 md:p-12 text-center border-t border-t-[var(--accent-primary)] bg-[var(--bg-main)]/80 backdrop-blur-xl">
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
               <Stars className="mx-auto text-[var(--accent-secondary)] mb-6 w-16 h-16 animate-pulse" />
               
               <h2 className="text-4xl md:text-5xl font-bold cursive text-[var(--text-main)] mb-6 leading-tight">
                  Welcome to the Celebration!
               </h2>
               
               <div className="space-y-4 text-lg md:text-xl text-[var(--text-muted)] mb-10 font-light leading-relaxed">
                  <p>
                     Aaj <span className="text-[var(--accent-primary)] font-bold">8th December</span> hai — Shivani ka Birthday! 🎂
                  </p>
                  <p>
                     Agar aap unhe ek chhota sa surprise dena chahte hain aur wishes bhejna chahte hain, toh aapka dil se swagat hai.
                  </p>
                  <p className="text-sm opacity-80 mt-4">
                     (Hello {userName}, we are so glad you are here!)
                  </p>
               </div>

               <motion.button
                  onClick={onComplete}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-10 py-4 rounded-full bg-[var(--accent-primary)] text-white font-bold text-lg shadow-lg hover:bg-pink-600 transition-colors flex items-center gap-2 mx-auto"
               >
                  <Heart className="fill-current" size={20} /> Enter Guest Portal
               </motion.button>
            </motion.div>
         </GlassCard>
      </div>
      <BottomBackButton onClick={onBack} />
    </PageTransition>
  );
};
