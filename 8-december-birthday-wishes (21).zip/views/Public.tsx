

import React, { useState, useEffect, useRef } from 'react';
import { Heart, LogOut, CheckCircle, Sparkles, Wand2, Loader2, Trash2, XCircle, Check, Edit3, Save, X, ArrowLeft, Image as ImageIcon, Upload } from 'lucide-react';
import { Wish, WishCategory, Story } from '../types';
import { db } from '../services/database';
import { generateWishSuggestion } from '../services/geminiService';
import { GlassCard, GlassInput, GlowingButton, PageTransition } from '../components/UI';
import { EditableText } from '../components/Editable';
import confetti from 'canvas-confetti';

interface PublicProps {
  onLogout: () => void;
  initialName?: string;
  isAdmin?: boolean;
  onExit?: () => void;
}

export const PublicPortal: React.FC<PublicProps> = ({ onLogout, initialName = '', isAdmin = false, onExit }) => {
  const [activeTab, setActiveTab] = useState<'WISHES' | 'MEMORIES'>('WISHES');
  const [wishes, setWishes] = useState<Wish[]>([]);
  
  // Wish Form
  const [name, setName] = useState(initialName);
  const [msg, setMsg] = useState('');
  const [category, setCategory] = useState<WishCategory>(WishCategory.FRIEND);
  const [sent, setSent] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  // Memory Form
  const [memName, setMemName] = useState(initialName);
  const [memContent, setMemContent] = useState('');
  const [memPhoto, setMemPhoto] = useState('');
  const [memSent, setMemSent] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Edit State
  const [editingWishId, setEditingWishId] = useState<string | null>(null);
  const [editWishText, setEditWishText] = useState('');

  useEffect(() => {
     refreshWishes();
  }, []);

  const refreshWishes = () => {
      // If admin, show all including pending. If guest, show only approved.
      const allWishes = db.getWishes();
      setWishes(isAdmin ? allWishes : allWishes.filter(w => w.isApproved));
  };

  const sendWish = (e: React.FormEvent) => {
    e.preventDefault();
    db.addWish({
      id: Date.now().toString(),
      senderName: name,
      message: msg,
      category,
      timestamp: Date.now(),
      isApproved: false, // Requires admin approval
      style: 'cute'
    });
    setSent(true);
    confetti({ particleCount: 50, origin: { y: 0.8 }, colors: ['#f59e0b', '#ec4899'] });
  };

  const sendMemory = (e: React.FormEvent) => {
      e.preventDefault();
      db.addStory({
          id: Date.now().toString(),
          author: memName,
          content: memContent,
          type: 'GUEST_MESSAGE',
          timestamp: Date.now(),
          photoUrl: memPhoto
      });
      setMemSent(true);
      confetti({ particleCount: 50, origin: { y: 0.8 }, colors: ['#3b82f6', '#8b5cf6'] });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files?.[0]) {
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === 'string') {
            setMemPhoto(reader.result);
          }
        };
        reader.readAsDataURL(e.target.files[0]);
      }
  };

  const handleAiGenerate = async (style: string) => {
    if (isGenerating) return;
    setIsGenerating(true);
    setMsg("Consulting the birthday fairies... ✨");
    const suggestion = await generateWishSuggestion(category, style);
    setMsg(suggestion);
    setIsGenerating(false);
  };

  // Admin Actions
  const deleteWish = (id: string) => {
      if(confirm("Delete this wish permanently?")) {
          db.deleteWish(id);
          refreshWishes();
      }
  };

  const toggleApproval = (id: string) => {
      db.toggleApproval(id);
      refreshWishes();
  }

  const startEditWish = (wish: Wish) => {
      setEditingWishId(wish.id);
      setEditWishText(wish.message);
  }

  const saveEditWish = (wish: Wish) => {
      db.updateWish({...wish, message: editWishText});
      setEditingWishId(null);
      refreshWishes();
  }

  return (
    <PageTransition>
      <div className={`min-h-screen p-6 relative z-10 pb-20 max-w-6xl mx-auto ${isAdmin ? 'pt-24' : ''}`}>
        
        {isAdmin && (
            <div className="mb-8 flex justify-center">
                 <button 
                    onClick={onExit}
                    className="flex items-center gap-2 px-6 py-3 bg-cyan-950/50 border border-cyan-500/50 text-cyan-300 rounded-full font-bold uppercase tracking-widest text-xs hover:bg-cyan-900/80 transition-colors shadow-[0_0_15px_rgba(6,182,212,0.3)]"
                 >
                    <ArrowLeft size={16} /> Return to Command Center
                 </button>
            </div>
        )}

        <header className="flex flex-col md:flex-row justify-between items-center mb-10 gap-4">
           <div>
             <h1 className="text-5xl sm:text-7xl font-bold text-[var(--text-main)] cursive text-shadow-glow text-center md:text-left">
                 <EditableText id="public_title" defaultText="Happy Birthday Shivani!" isAdmin={isAdmin} />
             </h1>
             <p className="text-[var(--accent-primary)] text-lg font-medium mt-2 text-center md:text-left">
                 <EditableText id="public_sub" defaultText="Join the celebration under the stars ✨" isAdmin={isAdmin} />
             </p>
           </div>
           
           <div className="flex gap-2 bg-[var(--bg-card)] p-1 rounded-full border border-[var(--border-color)]">
                <button 
                    onClick={() => setActiveTab('WISHES')} 
                    className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${activeTab === 'WISHES' ? 'bg-[var(--accent-primary)] text-white shadow-lg' : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'}`}
                >
                    Wishes
                </button>
                <button 
                    onClick={() => setActiveTab('MEMORIES')} 
                    className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${activeTab === 'MEMORIES' ? 'bg-[var(--accent-primary)] text-white shadow-lg' : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'}`}
                >
                    Share Memory
                </button>
           </div>

           {!isAdmin && (
             <button onClick={onLogout} className="bg-[var(--bg-input)] p-2 rounded-full text-[var(--accent-primary)] hover:bg-[var(--bg-card)] hover:text-[var(--text-main)] border border-[var(--accent-primary)]/20"><LogOut size={20}/></button>
           )}
        </header>

        {activeTab === 'WISHES' ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Form */}
            <div>
                <GlassCard className="p-8 sticky top-8 border-t-4 border-t-[var(--accent-primary)]/50">
                    <h2 className="text-3xl font-bold text-[var(--text-main)] mb-6 flex items-center gap-2 cursive">
                        <EditableText id="public_form_title" defaultText="Send Your Love" isAdmin={isAdmin} /> <Heart size={24} className="text-[var(--accent-primary)] fill-current animate-pulse"/>
                    </h2>
                    
                    {sent ? (
                        <div className="text-center py-10">
                        <CheckCircle size={64} className="mx-auto text-green-400 mb-4" />
                        <h3 className="text-2xl font-bold text-[var(--text-main)]">Wish Sent!</h3>
                        <p className="text-[var(--text-muted)] mb-4">It's flying to the admin for approval.</p>
                        <button onClick={() => { setSent(false); setMsg(''); }} className="text-[var(--accent-secondary)] font-bold hover:underline">Send Another</button>
                        </div>
                    ) : (
                        <form onSubmit={sendWish} className="space-y-6">
                        <div>
                            <label className="text-xs font-bold text-[var(--accent-primary)] uppercase tracking-wider mb-1 block ml-1">Your Name</label>
                            <GlassInput value={name} onChange={e => setName(e.target.value)} placeholder="e.g., Rahul" required className="text-[var(--text-main)]" />
                        </div>

                        <div>
                            <label className="text-xs font-bold text-[var(--accent-primary)] uppercase tracking-wider mb-2 block ml-1">Relationship</label>
                            <div className="flex gap-2">
                                {Object.values(WishCategory).map(cat => (
                                <button type="button" key={cat} onClick={() => setCategory(cat)} className={`flex-1 py-2 rounded-xl text-sm font-bold transition-all ${category === cat ? 'bg-gradient-to-r from-[var(--accent-primary)] to-purple-600 text-white shadow-lg shadow-[var(--accent-primary)]/30 scale-105' : 'bg-[var(--bg-input)] border border-[var(--border-color)] text-[var(--text-muted)] hover:bg-[var(--bg-card)]'}`}>{cat}</button>
                                ))}
                            </div>
                        </div>

                        <div>
                            <div className="flex justify-between items-center mb-2 px-1">
                                <label className="text-xs font-bold text-[var(--accent-primary)] uppercase tracking-wider">Your Message</label>
                                <div className="flex gap-1">
                                    {['Cute', 'Funny', 'Emotional'].map(style => (
                                        <button 
                                            key={style}
                                            type="button"
                                            disabled={isGenerating}
                                            onClick={() => handleAiGenerate(style)}
                                            className="text-[10px] bg-[var(--bg-card)] hover:bg-[var(--bg-input)] text-[var(--accent-primary)] px-2 py-1 rounded-full border border-[var(--accent-primary)]/30 transition-colors flex items-center gap-1"
                                        >
                                            {isGenerating ? <Loader2 size={8} className="animate-spin"/> : <Wand2 size={8} />}
                                            {style}
                                        </button>
                                    ))}
                                </div>
                            </div>
                            <textarea 
                            value={msg} 
                            onChange={e => setMsg(e.target.value)} 
                            required 
                            placeholder="Write something sweet... or use the magic wand above!" 
                            className="w-full h-32 bg-[var(--bg-input)] border border-[var(--border-color)] rounded-xl px-4 py-3 text-[var(--text-main)] placeholder-[var(--text-muted)] focus:outline-none focus:bg-[var(--bg-card)] resize-none transition-all" 
                            />
                        </div>

                        <GlowingButton className="w-full py-3 text-lg">Send Wish 🚀</GlowingButton>
                        </form>
                    )}
                </GlassCard>
            </div>

            {/* Wall */}
            <div className="space-y-6">
                <h2 className="text-3xl font-bold text-[var(--text-main)] flex items-center gap-2 cursive"><Sparkles className="text-[var(--accent-secondary)] fill-current"/> <EditableText id="public_wall_title" defaultText="Wall of Wishes" isAdmin={isAdmin} /></h2>
                <div className="space-y-4 max-h-[700px] overflow-y-auto pr-2 custom-scrollbar pb-10">
                    {wishes.map(w => (
                        <GlassCard key={w.id} className={`p-6 transform transition-transform border-l-4 ${w.isApproved ? 'border-l-[var(--accent-primary)]' : 'border-l-yellow-500'} ${isAdmin ? 'hover:scale-[1.01]' : 'hover:scale-[1.02]'}`}>
                        <div className="flex justify-between items-start mb-2">
                            <div className="flex items-center gap-2">
                                <h4 className="font-bold text-[var(--text-main)] text-lg">{w.senderName}</h4>
                                {isAdmin && !w.isApproved && <span className="text-[10px] bg-yellow-500/20 text-yellow-500 px-2 py-0.5 rounded uppercase font-bold border border-yellow-500/30">Pending</span>}
                            </div>
                            <span className="text-[10px] bg-[var(--bg-input)] px-2 py-1 rounded-full text-[var(--accent-primary)] font-bold uppercase">{w.category}</span>
                        </div>

                        {isAdmin && editingWishId === w.id ? (
                            <div className="animate-pulse-glow mb-4">
                                <textarea 
                                    value={editWishText} 
                                    onChange={e => setEditWishText(e.target.value)} 
                                    className="w-full bg-[rgba(10,10,30,0.8)] border border-cyan-500 text-cyan-300 p-2 rounded h-24"
                                />
                                <div className="flex gap-2 mt-2">
                                    <button onClick={() => saveEditWish(w)} className="bg-green-600/80 px-3 py-1 rounded text-white text-xs flex items-center gap-1"><Save size={12}/> Save</button>
                                    <button onClick={() => setEditingWishId(null)} className="bg-red-600/80 px-3 py-1 rounded text-white text-xs flex items-center gap-1"><X size={12}/> Cancel</button>
                                </div>
                            </div>
                        ) : (
                            <p className="text-[var(--text-muted)] text-sm leading-relaxed font-medium relative group">
                                "{w.message}"
                                {isAdmin && (
                                    <button onClick={() => startEditWish(w)} className="absolute -right-2 -top-2 text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity p-1">
                                        <Edit3 size={14}/>
                                    </button>
                                )}
                            </p>
                        )}
                        
                        {/* ADMIN CONTROLS */}
                        {isAdmin && (
                            <div className="mt-4 pt-3 border-t border-[var(--border-color)] flex justify-end gap-2">
                                <button onClick={() => toggleApproval(w.id)} className={`p-2 rounded-lg text-xs font-bold flex items-center gap-1 ${w.isApproved ? 'bg-yellow-900/30 text-yellow-400 hover:bg-yellow-900/50' : 'bg-green-900/30 text-green-400 hover:bg-green-900/50'}`}>
                                    {w.isApproved ? <><XCircle size={14}/> Unapprove</> : <><Check size={14}/> Approve</>}
                                </button>
                                <button onClick={() => deleteWish(w.id)} className="p-2 bg-red-900/30 text-red-400 hover:bg-red-900/50 rounded-lg"><Trash2 size={16}/></button>
                            </div>
                        )}
                        </GlassCard>
                    ))}
                    {wishes.length === 0 && (
                        <div className="text-center py-10 opacity-50">
                            <Heart size={48} className="mx-auto mb-2 text-[var(--accent-primary)]" />
                            <p className="text-[var(--text-muted)] italic">Be the first to wish her under the stars!</p>
                        </div>
                    )}
                </div>
            </div>

            </div>
        ) : (
            <div className="max-w-2xl mx-auto">
                 <GlassCard className="p-8 border-t-4 border-t-[var(--accent-secondary)]/50">
                     <h2 className="text-3xl font-bold text-[var(--text-main)] mb-2 cursive">Share a Memory</h2>
                     <p className="text-[var(--text-muted)] mb-6 text-sm">Have a special story or photo with Shivani? Share it privately here. She will see it in her story archive!</p>

                     {memSent ? (
                        <div className="text-center py-10">
                            <CheckCircle size={64} className="mx-auto text-blue-400 mb-4" />
                            <h3 className="text-2xl font-bold text-[var(--text-main)]">Memory Shared!</h3>
                            <button onClick={() => { setMemSent(false); setMemContent(''); setMemPhoto(''); }} className="mt-4 text-[var(--accent-secondary)] font-bold hover:underline">Share Another</button>
                        </div>
                     ) : (
                        <form onSubmit={sendMemory} className="space-y-4">
                            <div>
                                <label className="text-xs font-bold text-[var(--accent-primary)] uppercase tracking-wider mb-1 block">Your Name</label>
                                <GlassInput value={memName} onChange={e => setMemName(e.target.value)} required className="text-[var(--text-main)]" />
                            </div>
                            <div>
                                <label className="text-xs font-bold text-[var(--accent-primary)] uppercase tracking-wider mb-1 block">Story / Memory</label>
                                <textarea value={memContent} onChange={e => setMemContent(e.target.value)} required className="w-full bg-[var(--bg-input)] border border-[var(--border-color)] rounded-xl p-3 text-[var(--text-main)]" rows={4} />
                            </div>
                            <div>
                                <label className="text-xs font-bold text-[var(--accent-primary)] uppercase tracking-wider mb-1 block">Photo (Optional)</label>
                                <div onClick={() => fileInputRef.current?.click()} className="border-2 border-dashed border-[var(--border-color)] rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer hover:bg-[var(--bg-input)] transition-colors">
                                    {memPhoto ? (
                                        <img src={memPhoto} alt="Preview" className="h-32 object-cover rounded" />
                                    ) : (
                                        <>
                                            <Upload className="text-[var(--text-muted)] mb-2" />
                                            <span className="text-xs text-[var(--text-muted)]">Click to Upload Image</span>
                                        </>
                                    )}
                                </div>
                                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handlePhotoUpload} />
                            </div>
                            <GlowingButton className="w-full">Share Memory</GlowingButton>
                        </form>
                     )}
                 </GlassCard>
            </div>
        )}
      </div>
    </PageTransition>
  );
};